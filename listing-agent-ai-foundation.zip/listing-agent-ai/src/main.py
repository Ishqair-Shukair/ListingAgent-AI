"""
ListingAgent AI — starter orchestration skeleton
Run with: uvicorn src.main:app --reload
"""

from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse
from typing import List, Optional
import uuid

app = FastAPI(title="ListingAgent AI", version="0.1.0")

# In-memory store for demo
listings = {}


@app.get("/")
def root():
    return {"status": "ok", "product": "ListingAgent AI — Truthful Listing Content Agent"}


@app.post("/listings")
async def create_listing(
    photos: List[UploadFile] = File(...),
    address: str = Form(...),
    beds: Optional[int] = Form(None),
    baths: Optional[float] = Form(None),
    sqft: Optional[int] = Form(None),
    price: Optional[int] = Form(None),
    staging: bool = Form(False),
):
    listing_id = str(uuid.uuid4())
    # In production: save originals to object storage, queue generation job
    listings[listing_id] = {
        "id": listing_id,
        "address": address,
        "beds": beds,
        "baths": baths,
        "sqft": sqft,
        "price": price,
        "staging": staging,
        "photo_count": len(photos),
        "status": "queued",
        "assets": {},
    }
    return {"listing_id": listing_id, "status": "queued", "message": "Generation started (demo)"}


@app.get("/listings/{listing_id}")
def get_listing(listing_id: str):
    listing = listings.get(listing_id)
    if not listing:
        return JSONResponse(status_code=404, content={"error": "Not found"})
    return listing


@app.post("/listings/{listing_id}/generate")
def trigger_generate(listing_id: str):
    """Placeholder for the full fidelity pipeline."""
    if listing_id not in listings:
        return JSONResponse(status_code=404, content={"error": "Not found"})
    # TODO: call enhancement, video, text, compliance prompts
    listings[listing_id]["status"] = "complete"
    listings[listing_id]["assets"] = {
        "video": "https://example.com/demo-video.mp4",
        "description": "Factual description placeholder...",
        "disclosure": "Media includes AI-enhanced images...",
        "fidelity_score": 9.2,
    }
    return {"status": "complete", "listing_id": listing_id}
