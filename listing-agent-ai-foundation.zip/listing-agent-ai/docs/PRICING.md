# Pricing Model — ListingAgent AI

## Philosophy
Transparent, agent-friendly, aligned with value (time saved + risk reduced).  
Avoid opaque enterprise pricing that leaves solo agents behind.

## Recommended Tiers (MVP)

| Plan          | Price     | Included                     | Best for                  |
|---------------|-----------|------------------------------|---------------------------|
| Starter       | $29/mo    | 5 listings / month           | New or part-time agents   |
| Pro           | $79/mo    | 20 listings / month          | Active solo agents        |
| Team          | $199/mo   | 60 listings + 3 seats        | Small teams               |
| Pay-as-you-go | $12 / listing | No monthly commitment     | Occasional users          |

- Extra listings: $8–10 each on any plan
- Virtual staging add-on: included on Pro+, or $2/photo on Starter
- No watermarks on paid plans
- Originals always free to download

## ROI Messaging
- Traditional videographer: $1,500–$5,000 per listing
- Our cost: ~$4–$16 per listing at Pro volume
- Time saved: 3–8 hours of manual work per listing

## Future
- Outcome-based options (e.g., per inquiry attributed)
- Brokerage white-label
- Usage-based API for partners
