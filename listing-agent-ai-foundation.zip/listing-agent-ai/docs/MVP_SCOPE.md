# ListingAgent AI — MVP Scope

**Product**: Truthful, fidelity-first AI agent that turns listing photos + basic details into a complete, compliance-aware marketing kit for real estate agents.

**Core promise**: Full content kit in minutes without inventing features or creating liability.

## Target User
Solo agents and small teams who list 4–20 properties per month and currently:
- Hire videographers or skip video
- Manually write descriptions and social posts
- Worry about AI hallucinations and new disclosure laws

## MVP Inputs
- 8–20 listing photos (JPG/PNG)
- Property address or basic details (beds, baths, sqft, price, key features — optional MLS ID later)
- Agent branding (name, logo, preferred tone, headshot optional)
- Preferred formats (social vertical, MLS horizontal, email)

## MVP Outputs (the Content Kit)
1. **Enhanced photos** — lighting/color correction only; no added objects
2. **Optional virtual staging** — clearly labeled, reversible, original preserved
3. **Faithful video walkthrough** — 30–60s cinematic camera moves from real photos only
4. **Listing description** — factual, compliance-checked
5. **Social package** — Reels/Stories/TikTok captions + suggested hashtags
6. **Email / open-house text**
7. **Auto-generated disclosure** — “AI-enhanced media; original photos available”
8. **Review package** — side-by-side original vs output + approval checklist

## User Flow (MVP)
1. Agent uploads photos + fills short form (or pastes address)
2. Agent selects options (staging on/off, video length, tone)
3. System generates kit (async, 2–5 min)
4. Agent reviews fidelity report + outputs
5. Agent approves / regenerates specific assets
6. Download zip or one-click copy/export

## Out of Scope for MVP
- Full MLS bidirectional sync
- Auto-posting to social (export only)
- CRM deep integration
- Multi-agent collaboration
- Voice calls / lead qualification

## Success Metrics (first 90 days)
- Time-to-kit < 5 minutes
- Zero reported hallucinated features in beta
- 40%+ of beta agents produce a second listing
- Clear ROI messaging (hours saved vs videographer)

## Compliance Requirements
- Never invent architectural features, fixtures, or rooms
- Always preserve and offer originals
- Auto-append disclosure language
- Flag potentially prohibited fair-housing language
- Audit log of every generation

## Tech Stack (MVP)
- Backend: Python (FastAPI) + background tasks
- AI orchestration: structured prompts + model router (image enhance, video gen, text)
- Storage: S3-compatible for photos/videos
- Frontend: simple web app (or progressive web) — React or plain HTML + JS
- Auth: basic email magic link or Clerk/Auth0 later
