# Architecture — ListingAgent AI

## High-Level Flow

```
Agent Upload → Ingest & Validate → Fidelity Pipeline → Content Kit Assembly → Review & Export
```

## Components

### 1. Ingest Service
- Accepts photos + metadata
- Validates image quality / count
- Stores originals immutably
- Generates thumbnail set

### 2. Fidelity Pipeline (core differentiator)
- Photo enhancement (lighting, color, minor straighten) — no generative additions
- Optional staging (explicitly labeled, reversible)
- Video generation constrained to real photo geometry and lighting
- Hallucination guardrails (prompt + post-check)
- Compliance scanner (fair housing keywords, disclosure)

### 3. Content Kit Assembler
- Orchestrates parallel generation:
  - Video walkthrough
  - Listing description
  - Social captions (3 variants)
  - Email draft
  - Disclosure text
- Packages everything with review metadata

### 4. Review Layer
- Side-by-side comparison UI
- Per-asset regenerate
- Approval log

### 5. Export Service
- Zip download
- Individual asset links
- Later: social/CRM connectors

## Model Routing (MVP)
| Task                  | Preferred Model Class          | Notes                          |
|-----------------------|--------------------------------|--------------------------------|
| Photo enhance         | Image edit / upscale           | No generative fill             |
| Virtual staging       | Controlled image gen           | Strong negative prompts        |
| Video walkthrough     | Image-to-video                 | Photo-conditioned only         |
| Text (desc, social)   | Strong LLM                     | Factual grounding + checks     |
| Compliance check      | LLM + rules                    | Deterministic keyword layer    |

## Data Model (simplified)
- Listing (id, agent_id, address, metadata, status)
- Asset (type, original_url, generated_url, fidelity_score, approved)
- GenerationJob (inputs, prompts used, model versions, audit)

## Security & Trust
- Originals never overwritten
- Every generation logged with prompt + model version
- Agent owns all outputs
- No training on customer photos without explicit opt-in

## Deployment (MVP)
- Single FastAPI service + worker
- Object storage
- Simple Postgres for metadata
- Later: queue (Redis/Celery or background tasks)
