# ListingAgent AI

Truthful, fidelity-first AI agent that turns listing photos into a complete, compliance-aware marketing kit for real estate agents.

## Why it exists
Agents need video and polished content on every listing, but current AI tools hallucinate features, create liability under new disclosure laws, and force tool-hopping. This agent delivers a full kit while staying strictly faithful to the real property.

## Project structure
```
docs/           MVP scope, architecture, pricing, differentiation
prompts/        Fidelity-first prompt library
src/            Starter Python orchestration code
landing/        Sample landing page
```

## Quick start (development)
```bash
cd listing-agent-ai
python -m venv .venv
source .venv/bin/activate
pip install fastapi uvicorn python-multipart
uvicorn src.main:app --reload
```

## Status
Foundation complete — MVP scope, architecture, prompts, pricing, differentiation, starter code, and landing page.

## Next build steps
1. Wire real model APIs (image enhance, image-to-video, LLM)
2. Add simple upload UI
3. Implement fidelity check + review screen
4. Beta with 10–20 agents
