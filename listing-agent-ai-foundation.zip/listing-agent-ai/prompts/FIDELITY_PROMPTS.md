# Prompt Library — Fidelity-First

All prompts enforce: “Do not invent, add, or remove architectural features, fixtures, rooms, or permanent elements. Stay strictly faithful to the provided photos and facts.”

## 1. Photo Enhancement
```
Enhance lighting, color balance, and minor perspective on this real estate photo.
Do not add, remove, or alter any objects, fixtures, walls, windows, or furniture.
Preserve exact room geometry and contents.
Output a natural, professional listing photo.
```

## 2. Virtual Staging (optional, labeled)
```
Virtually stage this empty room photo with modern, neutral furniture appropriate for a [beds]-bedroom home.
Do not change walls, windows, floors, ceiling, or any permanent fixtures.
Clearly indicate this is virtual staging.
Provide both staged and original versions.
```

## 3. Video Walkthrough (image-to-video)
```
Create a smooth 45-second cinematic walkthrough using ONLY the provided listing photos.
Camera moves should feel natural (slow push-ins, gentle pans).
Do not invent rooms, features, or transitions that are not supported by the photos.
Maintain consistent lighting and geometry.
No people, no added objects, no fantasy elements.
```

## 4. Listing Description
```
Write a factual listing description for:
Address: {address}
Details: {beds} bed, {baths} bath, {sqft} sqft, listed at {price}
Key features from photos/agent: {features}

Rules:
- Only state facts provided or clearly visible.
- No superlatives that imply unverified claims.
- Avoid fair-housing prohibited language.
- 120–180 words.
- End with a soft call to action.
```

## 5. Social Captions (3 variants)
```
Generate 3 short social captions for a new listing video/photos.
Tone: professional yet approachable.
Include 1–2 relevant hashtags.
Do not invent features.
Variants: (1) Just listed, (2) Open house teaser, (3) Feature highlight.
```

## 6. Compliance / Disclosure
```
Generate standard disclosure text:
"Media includes AI-enhanced images and video generated from original photos. Original unaltered photos available upon request. Virtual staging (if used) is digitally added and not part of the property."
Also scan the description for any potentially prohibited language and flag it.
```

## 7. Fidelity Check (post-generation)
```
Compare the generated asset against the original photos and provided facts.
List any potential invented elements, geometric inconsistencies, or unsupported claims.
Score fidelity 1–10 and explain.
```
